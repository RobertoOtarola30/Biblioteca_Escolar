package com.biblioteca.vista;

import com.biblioteca.dao.UsuarioDAO;
import com.biblioteca.modelo.Usuario;
import javax.swing.*;
        import java.awt.*;

public class LoginView extends JFrame {
    private JTextField txtCorreo;
    private JPasswordField txtContrasena;

    public LoginView() {
        setTitle("Biblioteca - Login"); setSize(350, 200); setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE); setLocationRelativeTo(null); setLayout(new GridLayout(4, 2, 10, 10));
        add(new JLabel(" Correo:")); txtCorreo = new JTextField(); add(txtCorreo);
        add(new JLabel(" Contraseña:")); txtContrasena = new JPasswordField(); add(txtContrasena);
        add(new JLabel("")); JButton btnLogin = new JButton("Ingresar"); add(btnLogin);

        btnLogin.addActionListener(e -> {
            Usuario u = new UsuarioDAO().autenticar(txtCorreo.getText(), new String(txtContrasena.getPassword()));
            if (u != null) {
                new MainMenuView(u.getRol()).setVisible(true);
                this.dispose();
            } else { JOptionPane.showMessageDialog(this, "Credenciales incorrectas."); }
        });
    }
}