package com.biblioteca.dao;

import com.biblioteca.conexion.DatabaseConnection;
import com.biblioteca.modelo.Prestamo;
import java.sql.*;
import java.time.LocalDate;

public class PrestamoDAO {

    public int registrarPrestamoConValidacion(Prestamo p) {
        String sqlInsertar = "INSERT INTO prestamos (id_estudiante, id_libro, fecha_prestamo, fecha_devolucion, devuelto, observacion_atraso) VALUES (?, ?, ?, ?, FALSE, 'Pendiente')";
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmtIns = conn.prepareStatement(sqlInsertar)) {
            stmtIns.setInt(1, p.getIdEstudiante());
            stmtIns.setInt(2, p.getIdLibro());
            stmtIns.setDate(3, p.getFechaPrestamo());
            stmtIns.setDate(4, p.getFechaDevolucion());
            return stmtIns.executeUpdate() > 0 ? 1 : 0;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 1;
    }

    public String registrarDevolucionConControlAtraso(int idPrestamo, int idLibro) {
        String sqlBusqueda = "SELECT fecha_devolucion FROM prestamos WHERE (id = ? OR id_libro = ?) AND devuelto = FALSE LIMIT 1";
        String sqlUpdatePrestamo = "UPDATE prestamos SET devuelto = TRUE, observacion_atraso = ? WHERE (id = ? OR id_libro = ?) AND devuelto = FALSE";
        String sqlAumentarStock = "UPDATE libros SET stock = stock + 1 WHERE id = ?";

        try (Connection conn = DatabaseConnection.getInstance().getConnection()) {
            Date fechaLimite = null;
            try (PreparedStatement stmtB = conn.prepareStatement(sqlBusqueda)) {
                stmtB.setInt(1, idPrestamo);
                stmtB.setInt(2, idLibro);
                try (ResultSet rs = stmtB.executeQuery()) {
                    if (rs.next()) {
                        fechaLimite = rs.getDate("fecha_devolucion");
                    }
                }
            }

            String observacion = "Devuelto a tiempo";
            if (fechaLimite != null) {
                LocalDate hoy = LocalDate.now();
                LocalDate limite = fechaLimite.toLocalDate();
                if (hoy.isAfter(limite)) {
                    long diasAtraso = java.time.temporal.ChronoUnit.DAYS.between(limite, hoy);
                    observacion = "ATRASADO (" + diasAtraso + " días de retraso)";
                }
            } else {
                observacion = "Devuelto (Sin registro previo activo)";
            }

            try (PreparedStatement stmtU = conn.prepareStatement(sqlUpdatePrestamo)) {
                stmtU.setString(1, observacion);
                stmtU.setInt(2, idPrestamo);
                stmtU.setInt(3, idLibro);
                stmtU.executeUpdate();
            }

            // Aumenta el stock del libro al devolverlo
            try (PreparedStatement stmtStock = conn.prepareStatement(sqlAumentarStock)) {
                stmtStock.setInt(1, idLibro);
                stmtStock.executeUpdate();
            }

            return observacion;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return "Error al procesar la devolución.";
    }

    public String obtenerLibrosMasPrestados() {
        String sql = "SELECT l.titulo, COUNT(p.id_libro) as total FROM prestamos p JOIN libros l ON p.id_libro = l.id GROUP BY l.id ORDER BY total DESC LIMIT 5";
        StringBuilder sb = new StringBuilder("=== TOP LIBROS MÁS PRESTADOS ===\n\n");
        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            while (rs.next()) {
                sb.append("• ").append(rs.getString("titulo"))
                        .append(" | Total Préstamos: ").append(rs.getInt("total")).append("\n");
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return sb.toString();
    }

    public String obtenerLibrosActualmenteEnPrestamo() {
        String sql = "SELECT p.id, p.id_estudiante, e.nombre as estudiante, l.titulo, p.fecha_prestamo, p.fecha_devolucion FROM prestamos p JOIN estudiantes e ON p.id_estudiante = e.id JOIN libros l ON p.id_libro = l.id WHERE p.devuelto = FALSE";
        StringBuilder sb = new StringBuilder("=== LIBROS ACTUALMENTE EN PRÉSTAMO ===\n\n");
        LocalDate hoy = LocalDate.now();

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery(sql)) {
            boolean hayRegistros = false;
            while (rs.next()) {
                hayRegistros = true;
                LocalDate limite = rs.getDate("fecha_devolucion").toLocalDate();
                String estado = hoy.isAfter(limite) ? " [!] ¡ATRASADO!" : " [En plazo]";

                sb.append("• Préstamo ID: ").append(rs.getInt("id"))
                        .append(" | Estudiante: ").append(rs.getString("estudiante"))
                        .append(" (ID: ").append(rs.getInt("id_estudiante")).append(")")
                        .append("\n  Libro: ").append(rs.getString("titulo"))
                        .append(" | Vencimiento: ").append(limite).append(estado)
                        .append("\n----------------------------------------\n");
            }
            if (!hayRegistros) sb.append("No hay libros en préstamo actualmente.");
        } catch (SQLException e) { e.printStackTrace(); }
        return sb.toString();
    }

    public String obtenerHistorialPorEstudiante(int idEstudiante) {
        String sql = "SELECT l.titulo, p.fecha_prestamo, p.fecha_devolucion, p.devuelto, p.observacion_atraso FROM prestamos p JOIN libros l ON p.id_libro = l.id WHERE p.id_estudiante = ?";
        StringBuilder sb = new StringBuilder("=== HISTORIAL DE PRÉSTAMOS (Estudiante ID: " + idEstudiante + ") ===\n\n");

        try (Connection conn = DatabaseConnection.getInstance().getConnection();
             PreparedStatement stmt = conn.prepareStatement(sql)) {
            stmt.setInt(1, idEstudiante);
            try (ResultSet rs = stmt.executeQuery()) {
                boolean hayRegistros = false;
                while (rs.next()) {
                    hayRegistros = true;
                    String estadoDev = rs.getBoolean("devuelto") ? "Devuelto" : "Pendiente";
                    sb.append("• Libro: ").append(rs.getString("titulo"))
                            .append("\n  - Fecha Préstamo: ").append(rs.getDate("fecha_prestamo"))
                            .append("\n  - Fecha Vencimiento: ").append(rs.getDate("fecha_devolucion"))
                            .append("\n  - Estado: ").append(estadoDev)
                            .append("\n  - Detalle: ").append(rs.getString("observacion_atraso"))
                            .append("\n----------------------------------------\n");
                }
                if (!hayRegistros) sb.append("No hay registros para este estudiante.");
            }
        } catch (SQLException e) { e.printStackTrace(); }
        return sb.toString();
    }
}