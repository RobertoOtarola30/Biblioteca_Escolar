package com.biblioteca.modelo;

public class Usuario {
    private int id;
    private String nombre;
    private String rut;
    private String correo;
    private String contrasena;
    private String rol;

    public Usuario() {}

    public Usuario(int id, String nombre, String rut, String correo, String contrasena, String rol) {
        this.id = id; this.nombre = nombre; this.rut = rut; this.correo = correo; this.contrasena = contrasena; this.rol = rol;
    }

    public int getId() { return id; }
    public String getNombre() { return nombre; }
    public String getRut() { return rut; }
    public String getCorreo() { return correo; }
    public String getContrasena() { return contrasena; }
    public String getRol() { return rol; }
}